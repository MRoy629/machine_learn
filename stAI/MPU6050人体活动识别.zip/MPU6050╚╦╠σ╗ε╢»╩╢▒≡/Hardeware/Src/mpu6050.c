/*
 * mpu6050.c
 *
 *  Created on: Jan 25, 2024
 *      Author: wg
 */


#include "mpu6050.h"
#include "MyIIC.h"

#define MPU_INT_PORT GPIOB
#define MPU_INT_PIN  GPIO_PIN_12

#define CLK_ENABLE __HAL_RCC_GPIOB_CLK_ENABLE();

iic_bus_t MPU_bus =
{
	.IIC_SDA_PORT = GPIOA,
	.IIC_SCL_PORT = GPIOA,
	.IIC_SDA_PIN  = GPIO_PIN_11,
	.IIC_SCL_PIN  = GPIO_PIN_12,
};
//  外部中断初始化
//void MPU_INT_Pin_Init()
//{
//	GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//  /* GPIO Ports Clock Enable */
//  __HAL_RCC_GPIOB_CLK_ENABLE();
//
//  /*Configure GPIO pin : PB12 */
//  GPIO_InitStruct.Pin = GPIO_PIN_12;
//  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
//  GPIO_InitStruct.Pull = GPIO_PULLUP;
//  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
//
//  /* EXTI interrupt init*/
//  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
//}
//运动检测初始化
void MPU_Motion_Init(void)
{
    MPU_Write_Byte(MPU_MOTION_DET_REG,0x01);    //set the acceleration threshold is (LSB*2)mg 以便在达到一定的加速度变化时触发运动检测
    MPU_Write_Byte(MPU_MOTION_DUR_REG,0x01);    //Acceleration detection time is ()ms
    MPU_Write_Byte(MPU_INTBP_CFG_REG,0X90);     //INT Pin active low level, reset until 50us
    MPU_Write_Byte(MPU_INT_EN_REG,0x40);       	//enable INT
}

void MPU_Bus_Init(void)
{
	CLK_ENABLE;
	IICInit(&MPU_bus);
}

//MPU6050初始化

u8 MPU_Init(void)
{
	u8 res;

	MPU_Bus_Init();

	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X80);	//复位MPU6050
   delay_ms(100);
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X00);	//解除睡眠模式MPU6050
	MPU_Set_Gyro_Fsr(3);										//陀螺仪量程[-2000,2000]dps
	MPU_Set_Accel_Fsr(1);										//加速度计量程范围[-8,8]g
	MPU_Set_Rate(25);												//设置采样速度25Hz
	MPU_Write_Byte(MPU_INT_EN_REG,0X00);		//中断使能，0x00没有使能任何一个中断任务
	MPU_Write_Byte(MPU_USER_CTRL_REG,0X00);	//IIC用户控制寄存器
	MPU_Write_Byte(MPU_FIFO_EN_REG,0X00);		//IFO
	MPU_Write_Byte(MPU_INTBP_CFG_REG,0X80);	//INT active low

	res=MPU_Read_Byte(MPU_DEVICE_ID_REG);//读取MP6050 ID
	if(res==MPU_ADDR)//ID
	{
		MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X28);	//SET the internal 8MHz,sleep=0 不进入睡眠模式,cycle=1 循环模式在睡眠和唤醒模式之间切换,TEMP_DIS=1//low power modes
		MPU_Write_Byte(MPU_PWR_MGMT2_REG,0X87);	//enable accelerometer,disanable gyroscope,set the wake up frequence=5Hz
		MPU_Set_Rate(25);						//25Hz
 	}else return 1;

//	MPU_Motion_Init();//运动检测初始化
//	MPU_INT_Pin_Init();//外部中断初始化


	return 0;
}

void MPU_Sleep()
{
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0x48);//sleep=1,cycle=0,temp_dis=1,internal 8MHz
}

void MPU_Wakeup()
{
	//low power modes
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0x28);//sleep=0,cycle=1,temp_dis=1,internal 8MHz
}

uint8_t MPU_Read_Status()
{
	return MPU_Read_Byte(MPU_INT_STA_REG);
}

//配置MPU6050陀螺仪的全比例范围
//fsr:0,量程范围[-250,250]dps;1,[-500,500]dps;2,[-1000,1000]dps;3,[-2000,2000]dps

u8 MPU_Set_Gyro_Fsr(u8 fsr)
{
	return MPU_Write_Byte(MPU_GYRO_CFG_REG,fsr<<3);
}
//配置MPU6050加速度计的全比例范围
//fsr:0,[-2,2]g;1,[-4,4]g;2,[-8,8]g;3,[-16,16]g

u8 MPU_Set_Accel_Fsr(u8 fsr)
{
	return MPU_Write_Byte(MPU_ACCEL_CFG_REG,fsr<<3);
}
//MPU6050  设置 MPU6050 的低通滤波器截止频率（LPF）
// 低通滤波器可以用于平滑加速度和陀螺仪的测量值，以减小高频噪声的影响
u8 MPU_Set_LPF(u16 lpf)
{
	u8 data=0;
	if(lpf>=188)data=1;
	else if(lpf>=98)data=2;
	else if(lpf>=42)data=3;
	else if(lpf>=20)data=4;
	else if(lpf>=10)data=5;
	else data=6;
	return MPU_Write_Byte(MPU_CFG_REG,data);
}
//PU6050(Fs=1KHz)
//rate:4~1000(Hz)
//
//
u8 MPU_Set_Rate(u16 rate)
{
	u8 data;
	if(rate>1000)rate=1000;
	if(rate<4)rate=4;
	data=1000/rate-1;
	data=MPU_Write_Byte(MPU_SAMPLE_RATE_REG,data);	//设置分频数据
 	return MPU_Set_LPF(rate/2);	//根据频率设置低通滤波器的值
}


//获取温度
short MPU_Get_Temperature(void)
{
    u8 buf[2];
    short raw;
		float temp;
		MPU_Read_Len(MPU_ADDR,MPU_TEMP_OUTH_REG,2,buf);
    raw=((u16)buf[0]<<8)|buf[1];
    temp=36.53+((double)raw)/340;
    return temp*100;;
}

//获取三轴陀螺仪的值gx,gy,gz

u8 MPU_Get_Gyroscope(short *gx,short *gy,short *gz)
{
    u8 buf[6],res;
		res=MPU_Read_Len(MPU_ADDR,MPU_GYRO_XOUTH_REG,6,buf);
		if(res==0)
		{
			*gx=((u16)buf[0]<<8)|buf[1];
			*gy=((u16)buf[2]<<8)|buf[3];
			*gz=((u16)buf[4]<<8)|buf[5];
		}
    return res;;
}

//获取三轴加速度ax,ay,az:

u8 MPU_Get_Accelerometer(short *ax,short *ay,short *az)
{
    u8 buf[6],res;
		res=MPU_Read_Len(MPU_ADDR,MPU_ACCEL_XOUTH_REG,6,buf);
		if(res==0)
		{
			*ax=((u16)buf[0]<<8)|buf[1];
			*ay=((u16)buf[2]<<8)|buf[3];
			*az=((u16)buf[4]<<8)|buf[5];
		}
    return res;;
}
//写函数
//addr:设备地址
//reg:寄存器地址
//len:数据长度
//buf:数据地址
//
u8 MPU_Write_Len(u8 addr,u8 reg,u8 len,u8 *buf)
{
	u8 i;
  IICStart(&MPU_bus);
	IICSendByte(&MPU_bus,(addr<<1)|0);//左移一位0
	if(IICWaitAck(&MPU_bus))	//�ȴ�Ӧ��
	{
		IICStop(&MPU_bus);
		return 1;
	}
    IICSendByte(&MPU_bus,reg);	//д�Ĵ�����ַ
    IICWaitAck(&MPU_bus);		//�ȴ�Ӧ��
	for(i=0;i<len;i++)
	{
		IICSendByte(&MPU_bus,buf[i]);	//��������
		if(IICWaitAck(&MPU_bus))		//�ȴ�ACK
		{
			IICStop(&MPU_bus);
			return 1;
		}
	}
    IICStop(&MPU_bus);
	return 0;
}

//IIC写一个字节的数据

u8 MPU_Write_Byte(u8 reg,u8 data)
{
  IICStart(&MPU_bus);
	IICSendByte(&MPU_bus, (MPU_ADDR<<1)|0);//����������ַ+д����
	if(IICWaitAck(&MPU_bus))	//�ȴ�Ӧ��
	{
		IICStop(&MPU_bus);
		return 1;
	}
	IICSendByte(&MPU_bus,reg);	//д�Ĵ�����ַ
	IICWaitAck(&MPU_bus);		//�ȴ�Ӧ��
	IICSendByte(&MPU_bus,data);//��������
	if(IICWaitAck(&MPU_bus))	//�ȴ�ACK
	{
		IICStop(&MPU_bus);
		return 1;
	}
  IICStop(&MPU_bus);
	return 0;
}
//IIC读取一个字节的数据
u8 MPU_Read_Byte(u8 reg)
{
	u8 res;
  IICStart(&MPU_bus);
	IICSendByte(&MPU_bus,(MPU_ADDR<<1)|0);
	IICWaitAck(&MPU_bus);
  IICSendByte(&MPU_bus,reg);
  IICWaitAck(&MPU_bus);
  IICStart(&MPU_bus);
	IICSendByte(&MPU_bus,(MPU_ADDR<<1)|1);
  IICWaitAck(&MPU_bus);
	res=IICReceiveByte(&MPU_bus);
	IICSendNotAck(&MPU_bus);
  IICStop(&MPU_bus);
	return res;
}

// 读取指定长度的数据
u8 MPU_Read_Len(u8 addr,u8 reg,u8 len,u8 *buf)
{
 	IICStart(&MPU_bus);
	IICSendByte(&MPU_bus,(addr<<1)|0);
	if(IICWaitAck(&MPU_bus))
	{
		IICStop(&MPU_bus);
		return 1;
	}
    IICSendByte(&MPU_bus,reg);
    IICWaitAck(&MPU_bus);
    IICStart(&MPU_bus);
		IICSendByte(&MPU_bus,(addr<<1)|1);
    IICWaitAck(&MPU_bus);
		while(len)
		{
			if(len==1)
			{
				*buf=IICReceiveByte(&MPU_bus);
				IICSendNotAck(&MPU_bus);//如果只想读一个字节的数据，就发送NotAck
			}
			else
			{
				*buf=IICReceiveByte(&MPU_bus);
				IICSendAck(&MPU_bus);//连续读取多个字节，想要继续读取数据接收一个字节后发送一个Ack
			}
			len--;
			buf++;
		}
    IICStop(&MPU_bus);
		return 0;
}
//写多个字节的数据
uint8_t MPU_Write_Multi_Byte(uint8_t addr,uint8_t length,uint8_t buff[])
{
	if(IIC_Write_Multi_Byte(&MPU_bus,MPU_ADDR<<1,addr,length,buff))
	{
		return 1;
	}
	return 0;
}
// 读多个字节的数据
uint8_t MPU_Read_Multi_Byte(uint8_t addr, uint8_t length, uint8_t buff[])
{
	if(IIC_Read_Multi_Byte(&MPU_bus, MPU_ADDR<<1, addr, length, buff))
	{
		return 1;
	}
	return 0;
}

//计算俯仰角pitch
//计算横滚角度Roll
void MPU_Get_Angles(float * roll,float * pitch)
{
	short ax,ay,az;
	MPU_Get_Accelerometer(&ax,&ay,&az);
	*pitch = -atanf(ax/sqrtf(ay*ay+az*az));//atanf 反正切值
	*roll = atanf((float)ay/(float)az);
}
// 判断MPU6050是否处于水平状态
uint8_t MPU_isHorizontal(void)
{
	float roll,pitch;
	MPU_Get_Angles(&roll,&pitch);
	if(roll<=0.45 && roll>=-0.45 && pitch<=0.45 && pitch>=-0.45)
	{return 1;}
	return 0;
}

