/*
 * delay.h
 *
 *  Created on: Jan 24, 2024
 *      Author: wg
 */

#ifndef INC_DELAY_H_
#define INC_DELAY_H_

void delay_init(uint16_t sysclk);   /* 初始化延迟函数 */
void delay_ms(uint16_t nms);        /* 延时nms */
void delay_us(uint32_t nus);        /* 延时nus */

#endif /* INC_DELAY_H_ */
